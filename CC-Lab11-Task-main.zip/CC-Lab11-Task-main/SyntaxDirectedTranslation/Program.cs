﻿using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class SyntaxDirectedTranslation
{
    // Regex to match a valid variable name (variable names starting with letter or underscore followed by letters, digits or underscores)
    static Regex variable_Reg = new Regex(@"^[A-Za-z|_][A-Za-z|0-9]*$");

    static void Main(string[] args)
    {
        // Starting Syntax Directed Translation
        Console.WriteLine("Starting Syntax Directed Translation...");

        // Sample input (you should replace this with actual input or parser result)
        string[] finalArray = new string[] { "int", "x", "=", "5", "+", "3", ";" };

        // Simulate symbol table where variables will be stored and updated
        Dictionary<string, int> symbolTable = new Dictionary<string, int>();

        // Begin processing the finalArray (tokens)
        for (int i = 0; i < finalArray.Length; i++)
        {
            string token = finalArray[i];

            // Check for variable declaration like "int x"
            if (token == "int")
            {
                string varName = finalArray[i + 1];  // The next token should be the variable name
                if (variable_Reg.IsMatch(varName))
                {
                    symbolTable[varName] = 0; // Declare variable and initialize to 0
                    Console.WriteLine($"Declared variable: {varName} as int with initial value 0.");
                }
                else
                {
                    Console.WriteLine($"Error: Invalid variable name {varName}");
                }
                i++; // Skip the next token since it's already processed
            }
            // Check for assignment like "x = 5"
            else if (token == "=")
            {
                string varName = finalArray[i - 1];  // The variable being assigned
                if (symbolTable.ContainsKey(varName))
                {
                    int value;
                    if (int.TryParse(finalArray[i + 1], out value)) // The value on the right of "="
                    {
                        symbolTable[varName] = value;
                        Console.WriteLine($"Assigned {value} to variable {varName}.");
                    }
                    else
                    {
                        string rightToken = finalArray[i + 1];
                        if (symbolTable.ContainsKey(rightToken))  // Check if the right-hand side is a variable
                        {
                            int rightValue = symbolTable[rightToken];
                            symbolTable[varName] = rightValue;
                            Console.WriteLine($"Assigned value of {rightToken} ({rightValue}) to variable {varName}.");
                        }
                        else
                        {
                            Console.WriteLine($"Error: Invalid value or undeclared variable {rightToken} for assignment.");
                        }
                    }
                }
                else
                {
                    Console.WriteLine($"Error: Variable {varName} not declared.");
                }
                i++; // Skip the next token (value to assign)
            }
            // Check for operations like addition "x = 5 + 3"
            else if (token == "+")
            {
                string leftVar = finalArray[i - 1];  // Left operand (variable)
                string rightValue = finalArray[i + 1];  // Right operand (value)

                if (symbolTable.ContainsKey(leftVar))
                {
                    int leftValue = symbolTable[leftVar];
                    int rightValueInt;

                    if (int.TryParse(rightValue, out rightValueInt))  // Check if the right value is an integer
                    {
                        int result = leftValue + rightValueInt;
                        symbolTable[leftVar] = result;  // Update variable with result
                        Console.WriteLine($"Operation: {leftValue} + {rightValueInt} = {result}. Updated {leftVar} to {result}.");
                    }
                    else if (symbolTable.ContainsKey(rightValue))  // Check if right value is a declared variable
                    {
                        int rightVarValue = symbolTable[rightValue];
                        int result = leftValue + rightVarValue;
                        symbolTable[leftVar] = result;
                        Console.WriteLine($"Operation: {leftValue} + {rightVarValue} = {result}. Updated {leftVar} to {result}.");
                    }
                    else
                    {
                        Console.WriteLine($"Error: Invalid right operand {rightValue} for addition.");
                    }
                }
                else
                {
                    Console.WriteLine($"Error: Variable {leftVar} not declared.");
                }
                i++; // Skip the next token (right operand)
            }
            // Handle other statements, e.g., end of statement ";"
            else if (token == ";")
            {
                Console.WriteLine("End of statement.");
            }
            else
            {
                Console.WriteLine($"Unrecognized token: {token}");
            }
        }

        // Display the symbol table after all operations
        Console.WriteLine("\nSymbol Table After Execution:");
        foreach (var entry in symbolTable)
        {
            Console.WriteLine($"{entry.Key} = {entry.Value}");
        }

        // Semantic Analysis Completed
        Console.WriteLine("\nSemantic Analysis Completed Successfully.");
    }
}
