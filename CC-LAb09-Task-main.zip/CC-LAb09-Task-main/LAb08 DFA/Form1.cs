﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LAb08_DFA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


            private void btnValidate_Click(object sender, EventArgs e)
            {
                string input = txtInput.Text;

                // Call the DFA function and display results
                if (IsValidCVariable(input))
                {
                    lblResult.Text = "Valid C Variable Name";
                    lblResult.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblResult.Text = "Invalid C Variable Name";
                    lblResult.ForeColor = System.Drawing.Color.Red;
                }
            }

            private bool IsValidCVariable(string input)
            {
                // A variable name must be non-empty
                if (string.IsNullOrEmpty(input))
                    return false;

                // DFA starts in state 0
                int state = 0;

                // Loop through each character in the input
                foreach (char ch in input)
                {
                    switch (state)
                    {
                        case 0: // Start state
                            if (char.IsLetter(ch) || ch == '_') // Valid start character
                                state = 1; // Move to accept state
                            else
                                return false; // Invalid character at start
                            break;

                        case 1: // Accept state for valid start
                        case 2: // Accept state for subsequent valid characters
                            if (char.IsLetterOrDigit(ch) || ch == '_') // Valid subsequent character
                                state = 2; // Stay in accept state
                            else
                                return false; // Invalid character
                            break;

                        default:
                            return false; // Reject invalid state
                    }
                }

                // Final state must be 1 or 2 (accept states)
                return state == 1 || state == 2;
            }
        }
    }



