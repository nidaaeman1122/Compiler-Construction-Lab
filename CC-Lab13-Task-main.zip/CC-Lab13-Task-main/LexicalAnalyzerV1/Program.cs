﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace LexicalAnalyzerV1
{
    public partial class Form1 : Form
    {
        // Declare all necessary variables
        List<List<String>> Symboltable = new List<List<String>>();
        ArrayList LineNumber;
        ArrayList Variables;
        ArrayList KeyWords;
        ArrayList Constants;
        ArrayList finalArray;
        ArrayList tempArray;
        Regex variable_Reg;
        Regex constants_Reg;
        Regex operators_Reg;
        Regex specialCharacters_Reg;
        int lexemes_per_line;
        int ST_index;

        public Form1()
        {
            InitializeComponent();

            // Initialize arrays and lists
            String[] k_ = { "int", "float", "begin", "end", "print", "if", "else" };
            ArrayList key = new ArrayList(k_);
            LineNumber = new ArrayList();
            Variables = new ArrayList();
            KeyWords = new ArrayList();
            Constants = new ArrayList();
            finalArray = new ArrayList();
            tempArray = new ArrayList();
            variable_Reg = new Regex(@"^[A-Za-z|_][A-Za-z|0-9]*$");
            constants_Reg = new Regex(@"^[0-9]+([.][0-9]+)?([e]([+|-])?[0-9]+)?$");
            operators_Reg = new Regex(@"[+-/*=;>(){}]");
            specialCharacters_Reg = new Regex(@"^[.,'\[\]{}();:?]$");

            lexemes_per_line = 0;
            ST_index = 0;
        }

        private void btn_Input_Click(object sender, EventArgs e)
        {
            // Get user input from TextBox
            String userInput = tfInput.Text;
            List<String> keywordList = new List<String> { "int", "float", "while", "main", "if", "else", "new" };
            int row = 1;
            int count = 1;
            int line_num = 0;

            // Symbol Table structure
            String[,] SymbolTable = new String[20, 6];
            List<String> varListinSymbolTable = new List<String>();

            // Input Buffering
            ArrayList finalArray = new ArrayList();
            ArrayList finalArrayc = new ArrayList();
            ArrayList tempArray = new ArrayList();
            char[] charinput = userInput.ToCharArray();

            // Process user input
            for (int itr = 0; itr < charinput.Length; itr++)
            {
                Match Match_Variable = variable_Reg.Match(charinput[itr] + "");
                Match Match_Constant = constants_Reg.Match(charinput[itr] + "");
                Match Match_Operator = operators_Reg.Match(charinput[itr] + "");
                Match Match_Special = specialCharacters_Reg.Match(charinput[itr] + "");

                // Add matched tokens to tempArray
                if (Match_Variable.Success || Match_Constant.Success || Match_Operator.Success || Match_Special.Success || charinput[itr].Equals(' '))
                {
                    tempArray.Add(charinput[itr]);
                }

                // Process new line
                if (charinput[itr].Equals('\n'))
                {
                    if (tempArray.Count != 0)
                    {
                        string fin = string.Join("", tempArray.Cast<string>());
                        finalArray.Add(fin);
                        tempArray.Clear();
                    }
                }
            }

            // Process any remaining tokens
            if (tempArray.Count != 0)
            {
                string fin = string.Join("", tempArray.Cast<string>());
                finalArray.Add(fin);
                tempArray.Clear();
            }

            // Process each line
            tfTokens.Clear();
            SymbolTable.Clear();
            for (int i = 0; i < finalArray.Count; i++)
            {
                string line = finalArray[i].ToString();
                char[] lineChar = line.ToCharArray();
                line_num++;

                // Process each token in the line
                for (int itr = 0; itr < lineChar.Length; itr++)
                {
                    Match Match_Variable = variable_Reg.Match(lineChar[itr] + "");
                    Match Match_Constant = constants_Reg.Match(lineChar[itr] + "");
                    Match Match_Operator = operators_Reg.Match(lineChar[itr] + "");
                    Match Match_Special = specialCharacters_Reg.Match(lineChar[itr] + "");

                    if (Match_Variable.Success || Match_Constant.Success)
                    {
                        tempArray.Add(lineChar[itr]);
                    }

                    if (lineChar[itr].Equals(' '))
                    {
                        if (tempArray.Count != 0)
                        {
                            string fin = string.Join("", tempArray.Cast<string>());
                            finalArrayc.Add(fin);
                            tempArray.Clear();
                        }
                    }

                    if (Match_Operator.Success || Match_Special.Success)
                    {
                        if (tempArray.Count != 0)
                        {
                            string fin = string.Join("", tempArray.Cast<string>());
                            finalArrayc.Add(fin);
                            tempArray.Clear();
                        }
                        finalArrayc.Add(lineChar[itr].ToString());
                    }
                }

                // Process final tokens for the current line
                if (tempArray.Count != 0)
                {
                    string fina = string.Join("", tempArray.Cast<string>());
                    finalArrayc.Add(fina);
                    tempArray.Clear();
                }

                // Process lexemes and create tokens
                for (int x = 0; x < finalArrayc.Count; x++)
                {
                    Match operators = operators_Reg.Match(finalArrayc[x].ToString());
                    Match variables = variable_Reg.Match(finalArrayc[x].ToString());
                    Match digits = constants_Reg.Match(finalArrayc[x].ToString());
                    Match punctuations = specialCharacters_Reg.Match(finalArrayc[x].ToString());

                    if (operators.Success)
                    {
                        tfTokens.AppendText("< op, " + finalArrayc[x].ToString() + "> ");
                    }
                    else if (digits.Success)
                    {
                        tfTokens.AppendText("< digit, " + finalArrayc[x].ToString() + "> ");
                    }
                    else if (punctuations.Success)
                    {
                        tfTokens.AppendText("< punc, " + finalArrayc[x].ToString() + "> ");
                    }
                    else if (variables.Success)
                    {
                        if (!keywordList.Contains(finalArrayc[x].ToString()))
                        {
                            // Handle variable initialization
                            Regex reg1 = new Regex(@"^(int|float|double)\s([A-Za-z|_][A-Za-z|0-9]{0,10})\s(=)\s([0-9]+([.][0-9]+)?([e][+|-]?[0-9]+)?)\s(;)$");
                            Match category1 = reg1.Match(line);

                            Regex reg2 = new Regex(@"^(String|char)\s([A-Za-z|_][A-Za-z|0-9]{0,10})\s(=)\s[']\s([A-Za-z|_][A-Za-z|0-9]{0,30})\s[']\s(;)$");
                            Match category2 = reg2.Match(line);

                            if (category1.Success)
                            {
                                SymbolTable[row, 1] = row.ToString();
                                SymbolTable[row, 2] = finalArrayc[x].ToString();
                                SymbolTable[row, 3] = finalArrayc[x - 1].ToString();
                                SymbolTable[row, 4] = finalArrayc[x + 2].ToString();
                                SymbolTable[row, 5] = line_num.ToString();
                                tfTokens.AppendText("<var" + count + ", " + row + "> ");
                                symbolTable.AppendText(SymbolTable[row, 1] + "\t" + SymbolTable[row, 2] + "\t" + SymbolTable[row, 3] + "\t" + SymbolTable[row, 4] + "\t" + SymbolTable[row, 5] + "\n");
                                row++;
                                count++;
                            }
                            else if (category2.Success)
                            {
                                SymbolTable[row, 1] = row.ToString();
                                SymbolTable[row, 2] = finalArrayc[x].ToString();
                                SymbolTable[row, 3] = finalArrayc[x - 1].ToString();
                                SymbolTable[row, 4] = finalArrayc[x + 3].ToString();
                                SymbolTable[row, 5] = line_num.ToString();
                                tfTokens.AppendText("<var" + count + ", " + row + "> ");
                                symbolTable.AppendText(SymbolTable[row, 1] + "\t" + SymbolTable[row, 2] + "\t" + SymbolTable[row, 3] + "\t" + SymbolTable[row, 4] + "\t" + SymbolTable[row, 5] + "\n");
                                row++;
                                count++;
                            }
                            else
                            {
                                tfTokens.AppendText("<String" + count + ", " + finalArrayc[x] + "> ");
                            }
                        }
                    }
                    else
                    {
                        tfTokens.AppendText("<keyword, " + finalArrayc[x].ToString() + "> ");
                    }
                }

                tfTokens.AppendText("\n");
                finalArrayc.Clear();
            }

            // Display symbol table
            for (int j = 0; j < Symboltable.Count; j++)
            {
                for (int z = 0; z < Symboltable[j].Count; z++)
                {
                    symbolTable.AppendText(Symboltable[j][z].ToString() + "\t");
                }
                symbolTable.AppendText("\n");
            }
        }
    }
}
